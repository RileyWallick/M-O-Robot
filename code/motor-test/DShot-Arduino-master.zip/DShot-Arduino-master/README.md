# DShot-Arduino
DShot implementation for Arduino using bit-banging method

# Technical Detail
Refer to the post in [Stackexchange](https://arduino.stackexchange.com/questions/43851/dshot-implementation-on-arduino-esc-protocol)
